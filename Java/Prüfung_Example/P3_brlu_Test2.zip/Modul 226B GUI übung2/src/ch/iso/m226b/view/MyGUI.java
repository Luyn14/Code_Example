package ch.iso.m226b.view;

public class MyGUI {

	public static void main(String[] args) {

		final MyFrame myFrame = new MyFrame();
		myFrame.setDefaultCloseOperation(MyFrame.EXIT_ON_CLOSE);

		myFrame.setSize(800, 600);
		myFrame.setLocation(50, 50);
		myFrame.setVisible(true);
		
	}

}

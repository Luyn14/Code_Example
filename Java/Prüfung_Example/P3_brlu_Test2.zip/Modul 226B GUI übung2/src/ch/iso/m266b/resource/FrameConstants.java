package ch.iso.m266b.resource;

public class FrameConstants {

	public static final String FRAME_TITLE = "�bung 1 - Version 3";
	public static final String FRAME_BUTTON_NEW_LEFT = "neuer Eintrag";
	public static final String FRAME_BUTTON_NEW_RIGHT = "neuer Eintrag";
	public static final String FRAME_BUTTON_TO_LEFT = "<<<";
	public static final String FRAME_BUTTON_TO_RIGHT = ">>>";
	public static final Object FRAME_NEW_MESSAGE = "Bitte Eingeben";
	public static final String FRAME_NEW_TITLE = "Notification";

}

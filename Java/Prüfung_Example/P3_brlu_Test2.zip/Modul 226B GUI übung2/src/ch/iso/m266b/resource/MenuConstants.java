package ch.iso.m266b.resource;

public class MenuConstants {
	
	public static final String MENU_TOOLS = "Tools";
	public static final String MENU_TOOLS_DEL = "Daten l�schen";
	public static final String MENU_TOOLS_EXIT = "Programm Verlassen";

}

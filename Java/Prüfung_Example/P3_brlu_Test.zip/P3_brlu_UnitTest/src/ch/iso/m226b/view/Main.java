package ch.iso.m226b.view;

import static org.junit.jupiter.api.Assertions.assertEquals;

import ch.iso.m226b.view.Toolbox;

public class Main {

	public static void main(String[] args) {

		@SuppressWarnings("unused")
		Toolbox t = new Toolbox();

		// TODO: test concatenateTrimmedStringsToLowerCase
		System.out.println(t.concatenateTrimmedStringsToLowerCase("String 1", "sTring 2"));

		// TODO: test sumOfIntArray
		int[] a = new int[3];
		a[0] = 10;
		a[1] = 11;
		a[2] = 12;

		System.out.println(t.sumOfIntArray(a));

		// TODO: test multiplyString

		System.out.println(t.multiplyString("Hey"));
		System.out.println(t.multiplyString("Verylongstring"));

	}

}

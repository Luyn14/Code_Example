package ch.iso.m226b.view;

public class Toolbox {

	// returns concatenation of the two trimmed strings in lower case
	public String concatenateTrimmedStringsToLowerCase(String s1, String s2) {
		return s1.trim().concat(s2.trim()).toLowerCase();
	}

	// returns sum of array-entries or -1 if more than 99 entries
	public int sumOfIntArray(int[] a) {
		int sum = 0;

		if ((a.length > 0) && (a.length < 100)) {
			for (int i = 0; i < a.length; i++) {
				sum = sum + a[i];
			}

		} else if (a.length >= 100) {
			sum = -1;
		}
		return sum;
	}

	// returns multiplied string:
	// -> 10 times if string-length <= 5
	// -> 5 times if string-length > 5 and <= 10
	// -> once if string-length > 10
	public String multiplyString(String s) {
		String res = new String("");
		int count = 0;

		if (s.length() <= 5) {
			count = 10;
		} else if (s.length() <= 10) {
			count = 5;
		} else {
			count = 1;
		}

		for (int i = 0; i < count; i++) {
			res = res.concat(s);
		}

		return res;
	}

}

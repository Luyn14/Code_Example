package ch.iso.m226b.view;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ToolboxTest {

	@Test
	void testConcatenateTrimmedStringsToLowerCase() {
		Toolbox t = new Toolbox();

		assertEquals(t.concatenateTrimmedStringsToLowerCase("String 1 ", "sTring 2"), "string 1string 2");
	}

	@Test
	void testSumOfIntArray() {
		Toolbox t = new Toolbox();

		int[] a = new int[3];
		a[0] = 10;
		a[1] = 11;
		a[2] = 12;

		assertEquals(t.sumOfIntArray(a), 33);

		int[] b = new int[120];
		for (int i = 3; i < 102; i++) {
			b[i] = 5;

			assertEquals(t.sumOfIntArray(b), -1);
		}

	}

	@Test
	void testMultiplyString() {
		Toolbox t = new Toolbox();
		assertEquals(t.multiplyString("Hey"), "HeyHeyHeyHeyHeyHeyHeyHeyHeyHey");
		assertEquals(t.multiplyString("Longstring"), "LongstringLongstringLongstringLongstringLongstring");
		assertEquals(t.multiplyString("Verylongstring"), "Verylongstring");
	}
}

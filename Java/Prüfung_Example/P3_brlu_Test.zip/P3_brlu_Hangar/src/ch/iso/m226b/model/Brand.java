package ch.iso.m226b.model;

public class Brand {

	private String name;

	public Brand(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

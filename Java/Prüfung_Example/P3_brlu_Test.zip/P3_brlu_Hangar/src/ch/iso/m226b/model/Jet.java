package ch.iso.m226b.model;

public class Jet extends Aircraft {

	public Jet(String name, Brand brand) {
		super(name, brand);
	}

	public void fly() {
		System.out.println("jet: fly");
	}

}

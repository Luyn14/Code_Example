package ch.iso.m226b.model;

public class Warplane extends Aircraft {

	public Warplane(String name, Brand brand) {
		super(name, brand);
		// TODO Auto-generated constructor stub
	}

	public void fly() {
		System.out.println("warplane: fly");
	}
}

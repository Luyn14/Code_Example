package ch.iso.m226b.controller;

import ch.iso.m226b.model.Brand;
import ch.iso.m226b.model.Jet;
import ch.iso.m226b.model.Warplane;

public class Main {

	public static void main(String[] args) {

		// Brands erstellen
		Brand bBoe = new Brand("Boeing");
		Brand bAir = new Brand("Airbus");
		Brand bLock = new Brand("Lockheed");

		// Flugzeuge erstellen
		Jet j1 = new Jet("Jet 1", bBoe);
		Jet j2 = new Jet("Jet 2", bAir);
		Warplane w1 = new Warplane("Warplane 1", bLock);

		// Hanger erstellen
		Hangar h = new Hangar();

		// Flugzeuge zum Hanger hinzuf�gen
		h.addPlane(j1);
		h.addPlane(j2);
		h.addPlane(w1);

		h.showPlanes();

		System.out.println(j1.getName() + " -> " + j1.getBrand().getName());

	}

}

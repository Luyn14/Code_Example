package ch.iso.m226b.controller;

import java.util.ArrayList;

import ch.iso.m226b.model.Aircraft;

public class Hangar {

	private ArrayList<Aircraft> aircrafts = new ArrayList<>();

	public void addPlane(Aircraft a) {
		this.aircrafts.add(a);
	}

	public void showPlanes() {
		for (Aircraft ac : aircrafts) {
			System.out.println(ac.getName());
		}
	}
}
